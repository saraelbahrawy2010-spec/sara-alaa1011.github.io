document.addEventListener('DOMContentLoaded', function () {
  var form = document.getElementById('northview-newsletter-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var email = form.querySelector('input[name="northview_email"]').value;
      var btn = form.querySelector('button[type="submit"]');
      var originalText = btn.textContent;
      btn.textContent = 'Subscribing...';

      fetch((window.ajaxurl || '/wp-admin/admin-ajax.php'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=northview_newsletter&northview_email=' + encodeURIComponent(email)
      })
      .then(function (r) { return r.json(); })
      .then(function () {
        btn.textContent = 'Subscribed!';
        form.reset();
        setTimeout(function () { btn.textContent = originalText; }, 2500);
      })
      .catch(function () {
        btn.textContent = originalText;
        alert('Something went wrong. Please try again.');
      });
    });
  }
});
